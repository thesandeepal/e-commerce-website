from django.shortcuts import render
from django.http import HttpResponse
from PayTm import Checksum
from .models import Book,Contact,Orders,OrderUpdate
import json
from math import ceil
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
from django.http import HttpResponse
MERCHANT_KEY = 'enteryourMCKbb44'

def Index(request):
    #params = {'no_of_slides': nSlides, 'range': range(1, nSlides), 'product': products}
    allproduct=[]
    category_of_books=Book.objects.values('category','id')
    items_in_category={item["category"] for item in category_of_books}
    for categories in items_in_category:
        products = Book.objects.filter(category=categories)
        n = len(products)
        nSlides = n // 4 + ceil((n / 4) + (n // 4))
        allproduct.append([products,range(1,nSlides),nSlides])
    params={'allproduct':allproduct}
    return render(request, "Shop/index.html",params)
# Create your views here.
def About(request):
    return render(request,"Shop/about.html")
def Tracker(request):
    if request.method == "POST":
        orderId = request.POST.get('orderId', '')
        email = request.POST.get('email', '')
        try:
            order = Orders.objects.filter(order_id=orderId, email=email)
            if len(order) > 0:
                update = OrderUpdate.objects.filter(order_id=orderId)
                updates = []
                for item in update:
                    updates.append({'text': item.update_desc, 'time': item.timestamp})
                    response = json.dumps([updates, order[0].items_json],default = str)
                return HttpResponse(response)
            else:
                return HttpResponse('{}')
        except Exception as e:
            return HttpResponse('{}')

    return render(request,"Shop/tracker.html")


def Checkout(request):
    if request.method == "POST":
        items_json = request.POST.get('itemsJson', '')
        amount= request.POST.get('amount', '')
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        address=request.POST.get('address1','')+ " "+request.POST.get('address2','')
        city=request.POST.get('city','')
        zip_code=request.POST.get('zip_code','')
        state=request.POST.get('state','')
        orders= Orders(name=name,items_json=items_json, email=email, phone=phone, address=address, city=city, zip_code=zip_code, state=state,amount=amount)
        orders.save()
        update = OrderUpdate(order_id=orders.order_id, update_desc="The order has been placed")
        update.save()
        clear_cart_after_placing_orders= True
        id = orders.order_id
        #return render(request, "Shop/checkout.html", {"clear_cart_after_placing_orders":clear_cart_after_placing_orders,'id':id})
        param_dict = {

            'MID': '12345678910112233445',
            'ORDER_ID': str(Orders.order_id),
            'TXN_AMOUNT': str(amount),
            'CUST_ID': email,
            'INDUSTRY_TYPE_ID': 'Retail',
            'WEBSITE': 'WEBSTAGING',
            'CHANNEL_ID': 'WEB',
            'CALLBACK_URL': 'http://127.0.0.1:8000/shop/handlerequest/',

        }
        param_dict['CHECKSUMHASH']=Checksum.generate_checksum(param_dict,MERCHANT_KEY)
        return render(request, 'Shop/paytm.html', {'param_dict': param_dict})

    return render(request, 'Shop/checkout.html')
def contact(request):
    if request.method=="POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        desc = request.POST.get('desc', '')
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
        contact_submitted=True
        return render(request, "Shop/contact.html",{"contact_submitted":contact_submitted})
    return render(request,'Shop/contact.html')
def BookView(request,myid):
    book=Book.objects.filter(id=myid)
    return render(request,"Shop/bookview.html",{"book":book[0]})

#payment gateway
@csrf_exempt
def handlerequest(request):
    # paytm will send you post request here
    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]

    verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    if verify:
        if response_dict['RESPCODE'] == '01':
            print('order successful')
        else:
            print('order was not successful because' + response_dict['RESPMSG'])
    return render(request, 'shop/paymentstatus.html', {'response': response_dict})